

#include "MUG51.h"

#define print_function 

//sfr CKDIV = 0xC1;
#define I2C_CLOCK                 7
#define I2C_SLAVE_ADDRESS         0x7C
#define I2C_WR                    0
#define I2C_RD                    1

#define LOOP_SIZE                 1

void Init_I2C(void)
{
    MFP_P25_I2C0_SCL;
    P25_OPENDRAIN_MODE;          // Modify SCL pin to Open drain mode. don't forget the pull high resister in circuit
    MFP_P24_I2C0_SDA;
    P24_OPENDRAIN_MODE;          // Modify SDA pin to Open drain mode. don't forget the pull high resister in circuit

    SFRS = 0;
    /* Set I2C clock rate */
    I2C0CLK = I2C_CLOCK; 

    /* Enable I2C */
    set_I2C0CON_I2CEN;                                   
}

void I2C_Error(void)
{
   
  while(1);
}

void I2C_Write_Process(UINT8 u8DAT)
{
	
    unsigned char  u8Count;
    /* Write Step1 */
    set_I2C0CON_STA;                                    /* Send Start bit to I2C EEPROM */
    clr_I2C0CON_SI;
    while (!(I2C0CON&SET_BIT3));                                /*Check SI set or not  */
	      if (I2C0STAT != 0x08)                         /*Check status value after every step   */
        I2C_Error();
    
    /* Write Step2 */
    clr_I2C0CON_STA;                                    /*STA=0*/
    I2C0DAT = (I2C_SLAVE_ADDRESS | I2C_WR);
    clr_I2C0CON_SI;
    while (!(I2C0CON&SET_BIT3));                                /*Check SI set or not */
		    if (I2C0STAT != 0x18)              
						I2C_Error();

    /* Write Step3 */
    for (u8Count = 0; u8Count < LOOP_SIZE; u8Count++)
    {
        I2C0DAT = u8DAT;
        clr_I2C0CON_SI;
        while (!(I2C0CON&SET_BIT3)); 			/*Check SI set or not*/
				    if (I2C0STAT != 0x28)
            I2C_Error();
				
        u8DAT = ~u8DAT;
    }

    /* Write Step4 */
    set_I2C0CON_STO;
    clr_I2C0CON_SI;
    while (I2C0CON&SET_BIT4);                                /* Check STOP signal */
}
void my_delay(unsigned int time)
{
	volatile unsigned int i;
	volatile unsigned int j;
	i=time;
	for(i;i>0;i--)
	{
		 j=0;
		for(j;j<900;j++);
	}
}
#define LCD_CMD 0x80
#define LCD_DAT 0x40
#define LCD_FUN_SET 0X2C //0X38 //0x28
#define LCD_DIS_ON_OFF 0x0f
#define LCD_DIS_CLR 0x01
#define LCD_ENT_MODE 0x06
#define LCD_SET_DDRAM_FIRST_ROW 0x80
#define LCD_SET_DDRAM_SECOND_ROW 0xC0
#define MY_LOOP_SIZE 2



unsigned char i2c_data_buf[2];
void I2C_Write_Process_MultyByte(UINT8 *u8DAT, UINT8 data_size)
{
	
    unsigned char  u8Count;
    /* Write Step1 */
    set_I2C0CON_STA;                                    /* Send Start bit to I2C EEPROM */
    clr_I2C0CON_SI;
    while (!(I2C0CON&SET_BIT3));                                /*Check SI set or not  */
	      if (I2C0STAT != 0x08)                         /*Check status value after every step   */
        I2C_Error();
    
    /* Write Step2 */
    clr_I2C0CON_STA;                                    /*STA=0*/
    I2C0DAT = (I2C_SLAVE_ADDRESS | I2C_WR);
    clr_I2C0CON_SI;
    while (!(I2C0CON&SET_BIT3));                                /*Check SI set or not */
		    if (I2C0STAT != 0x18)              
						I2C_Error();

    /* Write Step3 */
    for (u8Count = 0; u8Count < data_size; u8Count++)
    {
        I2C0DAT = (UINT8)(*u8DAT);
        clr_I2C0CON_SI;
        while (!(I2C0CON&SET_BIT3)); 			/*Check SI set or not*/
				    if (I2C0STAT != 0x28)
            I2C_Error();
				
        //u8DAT = ~u8DAT;
				u8DAT++;
    }

    /* Write Step4 */
    set_I2C0CON_STO;
    clr_I2C0CON_SI;
    while (I2C0CON&SET_BIT4);                                /* Check STOP signal */
}

void main(void)
{
		
		unsigned char sysclkdiv;
	  
		sysclkdiv = CKDIV;
    Init_I2C();                                 /* initial I2C circuit  */
	  my_delay(1000);
	
		i2c_data_buf[0] = LCD_CMD;
		i2c_data_buf[1] = LCD_FUN_SET;
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
	
		i2c_data_buf[0] = LCD_CMD;
		i2c_data_buf[1] = LCD_FUN_SET;
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
	
		i2c_data_buf[0] = LCD_CMD;
		i2c_data_buf[1] = LCD_FUN_SET;
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
	
		i2c_data_buf[0] = LCD_CMD;
		i2c_data_buf[1] = LCD_FUN_SET;
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
	
		
		i2c_data_buf[0] = LCD_CMD;
		i2c_data_buf[1] = LCD_DIS_ON_OFF;
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
		
		my_delay(1000);
		
		i2c_data_buf[0] = LCD_CMD;
		i2c_data_buf[1] = LCD_DIS_CLR;
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
		
		my_delay(1000);
		
		i2c_data_buf[0] = LCD_CMD;
		i2c_data_buf[1] = LCD_ENT_MODE;
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
		
		my_delay(1000);
		
		i2c_data_buf[0] = LCD_CMD;
		i2c_data_buf[1] = LCD_SET_DDRAM_FIRST_ROW;
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
		
		my_delay(1000);
		
		i2c_data_buf[0] = LCD_DAT;
		i2c_data_buf[1] = 'A';
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
		
		my_delay(1000);
		
		i2c_data_buf[0] = LCD_DAT;
		i2c_data_buf[1] = '5';
		I2C_Write_Process_MultyByte(i2c_data_buf, 2);
		
		my_delay(1000);
	

    while (1);

}










/*void main (void)
{

  ALL_GPIO_PUSHPULL_MODE;
  while(1)
  {
    P3 = ~P3;
    SFRS = 2;
	  Timer2_Delay1ms(1000);
  }
}
*/


