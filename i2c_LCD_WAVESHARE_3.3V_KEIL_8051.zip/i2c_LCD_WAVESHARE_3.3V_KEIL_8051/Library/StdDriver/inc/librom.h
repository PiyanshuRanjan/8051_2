
void LIBROM_PD_RETURN(void);
void LIBROM_LOOP_RETURN(void);
void LIBROM_DELAY_10US(void);
void LIBROM_DELAY_50US(void);
void LIBROM_DELAY_100US(void);
void LIBROM_DELAY_1MS(void);
void LIBROM_DELAY_10MS(void);
void LIBROM_DELAY_100MS(void);

